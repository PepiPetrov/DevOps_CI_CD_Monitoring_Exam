#!/bin/bash

echo "192.168.99.100 monitoring.do1.exam monitoring" >> /etc/hosts
echo "192.168.99.101 pipelines.do1.exam jenkins" >> /etc/hosts
echo "192.168.99.102 containers.do1.exam docker" >> /etc/hosts